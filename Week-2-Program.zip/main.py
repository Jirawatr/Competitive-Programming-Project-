(A[1 - 100])
for i [1 - n]
  for j [1 - n]
    if A[i]<A[j] then
     swap A[i] and A[j]