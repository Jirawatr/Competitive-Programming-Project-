N = list(range(-700,-549))

for i in N : 
  if i % 9 == 0 :
     print  ("foo")
  elif i % 11 == 0 :
     print  ("baz")
  elif i % 9 == 0 and i % 11 == 0 :
     print  ("foobaz")