i = list (range(1,10))
j = list (range(11,20))
for i = 1 to n do 
for j = 1 to n do 
if A(i) < A(j) then 
swap A(i) and A(j))
